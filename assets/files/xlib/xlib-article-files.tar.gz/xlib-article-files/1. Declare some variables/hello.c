/*
 * hello.c - a simple x window client built on xlib
 *   modified 20230131 wds
 */

#include <stdio.h>      // for fprintf
#include <stdlib.h>     // for exit
#include <X11/Xlib.h>   // for xlib stuff

int main(int argc, char** argv)
{
	/*
	 * 1. Declare variables
	*/

    // display vars
	Display* display;
	int screen;
	Window root;
	GC gc;

	// window vars
	Window window;
	Visual* visual = CopyFromParent;
	int x, y, width, height;
    char *message = "hello, world - click the mouse or press any key to exit.";
		
	// event loop - done and event variables
	int done = 0;
	XEvent event;

    /*
	 * 2. Connect to the X window server
	*/

	/*
	 * 3. Open a window
	*/
	
    /*
	 * 4. Set some hints
	*/

    /*
	 * 5. Display the window
	*/

    /*
	 * 6. Handle events
	*/


    /*
	 * 7. Close the Display
	*/

	return 0;
}

