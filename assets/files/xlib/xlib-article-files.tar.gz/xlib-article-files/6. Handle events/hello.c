/*
 * hello.c - a simple x window client built on xlib
 *   modified 20230131 wds
 */

#include <stdio.h>      // for fprintf
#include <stdlib.h>     // for exit
#include <X11/Xlib.h>   // for xlib stuff
#include <X11/Xutil.h>  // for XSizeHints etc.
#include <string.h>

void PrintDisplayInformation(Display* display, int screen);

int main(int argc, char** argv)
{
	/*
	 * 1. Declare variables
	*/

    // display vars
	Display* display;
	int screen;
	Window root;
	GC gc;

	// window vars
	Window window;
	Visual* visual = CopyFromParent;
	int x, y, width, height;
    char *message = "hello, world - click the mouse or press any key to exit.";
	int border_width = 2;
	char *application_class = "example_class";	
	// window attributes
	//   subscribe to events (Exposure, ButtonPress, and KeyPress), set bg and fg pixels
	XSetWindowAttributes attributes;
	unsigned long attribute_mask = CWEventMask | CWBackPixel | CWBorderPixel;
	unsigned long event_mask = ExposureMask|ButtonPressMask|KeyPressMask;

	// window hints - size, name, class, and window manager hints
	XSizeHints size_hints;
	char *window_name;
	XClassHint class_hints;
	XWMHints window_manager_hints;
		
	// event loop - done and event variables
	int done = 0;
	XEvent event;

    /*
	 * 2. Connect to the X window server
	*/

	display = XOpenDisplay((char*) NULL);
	if(display == (Display *) NULL) {
		fprintf(stderr, "Unable to connect to X server [%s]\n",
			XDisplayName((char*) NULL));
		exit(1);
	}

	screen = DefaultScreen(display);
	root = RootWindow(display, screen);
	gc = DefaultGC(display, screen);

	PrintDisplayInformation(display, screen);

	/*
	 * 3. Open a window
	*/

	// open a window in the top left corner that is 150 pixels from either edge
	// that is 500x100 pixels in size
	// subscribe the window to events, and set the border and background pixels
	x = y = 150;
	width = 500;
	height = 100;
	attributes.event_mask = event_mask;
	attributes.border_pixel = BlackPixel(display, screen),
	attributes.background_pixel = WhitePixel(display, screen);
	
	window = XCreateWindow( display, root, x, y, width, height,
		border_width, CopyFromParent, InputOutput,
		visual, attribute_mask, &attributes);
			
    /*
	 * 4. Set some hints
	*/

	size_hints.x = x;
	size_hints.y = y;
	size_hints.width = width;
	size_hints.height = height;
	size_hints.min_width = width;
	size_hints.min_height = height;
	size_hints.base_width = width;
	size_hints.base_height = height;
	size_hints.flags = USPosition | USSize | PMinSize | PBaseSize;	
	window_name = argv[0];
	class_hints.res_class = application_class;
	class_hints.res_name = window_name;
	window_manager_hints.flags = InputHint | StateHint;
	window_manager_hints.initial_state = NormalState;
	window_manager_hints.input = True;

	XSetWMNormalHints(display, window, &size_hints);
	XStoreName(display, window, window_name);
	XSetClassHint(display, window, &class_hints);
	XSetWMHints(display, window, &window_manager_hints);

    /*
	 * 5. Display the window
	*/

	XMapRaised(display, window);
	XFlush(display);

    /*
	 * 6. Handle events
	*/

	while(! done) {
		XNextEvent(display, &event);
		if(event.type == Expose) {
            XDrawString(display, window, gc, 50, 50, message, strlen(message));
			printf("For Expose event the area is:\n");
			printf("\tAt %d, %d,", event.xexpose.x, event.xexpose.y);
			printf(" %d pixels wide, %d high\n", event.xexpose.width,
				event.xexpose.height);
		}
		else if(event.type == ButtonPress) {
			printf("Button pressed\n");
			done = 1;
		}
		else if(event.type == KeyPress) {
			printf("Key pressed\n");
			done = 1;
		}
	}

    /*
	 * 7. Close the Display
	*/

	return 0;
}

void PrintDisplayInformation(Display* display, int screen) {
	int screen_num, display_width, display_height, width, height;
	
	

	/* get screen size from display structure macro */
	screen_num = DefaultScreen(display);
	display_width = DisplayWidth(display, screen_num);
	display_height = DisplayHeight(display, screen_num);

	fprintf(stderr, "DisplayString: %s\n", DisplayString(display));
	fprintf(stderr, "default screen index: %d\n", screen_num);
	fprintf(stderr, "display width: %d\n", display_width);
	fprintf(stderr, "display height: %d\n", display_height);
}
