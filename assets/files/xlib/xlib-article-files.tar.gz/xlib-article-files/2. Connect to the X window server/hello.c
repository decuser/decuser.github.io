/*
 * hello.c - a simple x window client built on xlib
 *   modified 20230131 wds
 */

#include <stdio.h>      // for fprintf
#include <stdlib.h>     // for exit
#include <X11/Xlib.h>   // for xlib stuff

void PrintDisplayInformation(Display* display, int screen);

int main(int argc, char** argv)
{
	/*
	 * 1. Declare variables
	*/

    // display vars
	Display* display;
	int screen;
	Window root;
	GC gc;

	// window vars
	Window window;
	Visual* visual = CopyFromParent;
	int x, y, width, height;
    char *message = "hello, world - click the mouse or press any key to exit.";
		
	// event loop - done and event variables
	int done = 0;
	XEvent event;

    /*
	 * 2. Connect to the X window server
	*/

	display = XOpenDisplay((char*) NULL);
	if(display == (Display *) NULL) {
		fprintf(stderr, "Unable to connect to X server [%s]\n",
			XDisplayName((char*) NULL));
		exit(1);
	}

	screen = DefaultScreen(display);
	root = RootWindow(display, screen);
	gc = DefaultGC(display, screen);

	PrintDisplayInformation(display, screen);

	/*
	 * 3. Open a window
	*/
	
    /*
	 * 4. Set some hints
	*/

    /*
	 * 5. Display the window
	*/

    /*
	 * 6. Handle events
	*/


    /*
	 * 7. Close the Display
	*/

	return 0;
}

void PrintDisplayInformation(Display* display, int screen) {
	int screen_num, display_width, display_height, width, height;
	
	

	/* get screen size from display structure macro */
	screen_num = DefaultScreen(display);
	display_width = DisplayWidth(display, screen_num);
	display_height = DisplayHeight(display, screen_num);

	fprintf(stderr, "DisplayString: %s\n", DisplayString(display));
	fprintf(stderr, "default screen index: %d\n", screen_num);
	fprintf(stderr, "display width: %d\n", display_width);
	fprintf(stderr, "display height: %d\n", display_height);
}
