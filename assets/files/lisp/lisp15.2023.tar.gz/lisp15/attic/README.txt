The file lisp15.html is originally from http://b54.net/lisp15

That web site is no longer available, and I do not know who the
original author was.

