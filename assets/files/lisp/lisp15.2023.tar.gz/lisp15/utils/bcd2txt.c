/***********************************************************************
*
* bcd2txt.c - IBM 7090 BCD to Text converter.
*
* Changes:
*   ??/??/??   PRP   Original.
*   01/28/05   DGP   Changed to use IBSYS standard characters as default.
*   03/18/05   DGP   Changed 072 usage, in altbcd it is a '?'.
*   05/31/06   DGP   Added simh support and blocking.
*   10/24/06   DGP   Remove length mask in tapereadint.
*   09/12/07   DGP   Correct Carriage control.
*   
***********************************************************************/


#include <stdlib.h>
#include <stdio.h>

#include "sysdef.h"
#include "nativebcd.h"
#include "prsf2.h"

char fin[300], fon[300];

static int altchars;
static int reclen;
static int chrrec;
static int simhfmt;
static int blank;
static int termc;
static int chkc;
static int printer;
static int fileflag;
static size_t chrblk;
static size_t blklen;

static uint8 block[MAXREC];
static uint8 record[MAXREC];

/***********************************************************************
* tapereadint - Read an integer.
***********************************************************************/

static size_t
tapereadint (FILE *fd)
{
   size_t r;

   r = fgetc (fd);
   r = r | (fgetc (fd) << 8);
   r = r | (fgetc (fd) << 16);
   r = r | (fgetc (fd) << 24);
   if (feof (fd)) return (EOF);
   return (r);
}

/***********************************************************************
* unmapchar - Map BCD char to local charset.
***********************************************************************/

static uint8
unmapchar (uint8 ch)
{
   return altchars ? toaltnative[ch & 077] : tonative[ch & 077];
}

/***********************************************************************
* readblock - Read block from input.
***********************************************************************/

static int
readblock (FILE *fd)
{
   int done;
   int c;

   if (simhfmt)
   {
      if ((blklen = tapereadint (fd)) < 0)
         return -1;
      if (blklen == 0) return EOF;
      if (fread (block, 1, blklen, fd) != blklen)
         return -1;
      if (tapereadint (fd) != blklen)
         return -1;
      block[0] |= 0200;
   }
   else
   {
      if ((c = fgetc (fd)) == EOF)
         return -1;
      if (c & 0200)
      {
         blklen = 0;
	 if (c == 0217) return EOF;
	 done = FALSE;
	 while (!done)
	 {
	    block[blklen++] = c;
	    if ((c = fgetc (fd)) == EOF)
	       return -1;
	    if (c & 0200) done = TRUE;
	 } 
	 ungetc (c, fd);
      }
      else
         return -1;
   }

   chrblk = 0;
   chrrec = 0;
   return 0;
}

/***********************************************************************
* outputrec - Output accumulated record.
***********************************************************************/

static uint8 *
outputrec (FILE *fd, uint8 *p, uint8 c)
{
   if (p != record)
   {
      while (p != record && p[-1] == ' ')
	 p--;

      if (p != record)
      {
	 fwrite (record, 1, p - record, fd);
	 fputc ('\n', fd);
      }
      else if (!fileflag)
      {
	 fputc ('\n', fd);
      }

      fileflag = FALSE;
      p = record;
   }

   if (printer && (c != 0377))
   {
      uint8 ch;

      if (c == termc)
      {
	 c = block[chrblk++];
	 chrrec++;
      }

      ch = unmapchar (c);
      switch (ch)
      {
      case '0':
	 fputc ('\n', fd);
	 break;
      case '1':
	 fputc ('\f', fd);
	 break;
      default: ;
      }
   }

   chrrec = 0;
   return p;
}

/***********************************************************************
* main - Main procedure.
***********************************************************************/

int
main (int argc, char **argv)
{
   FILE *fi, *fo;
   uint8 *p;
   char *optarg;
   int optind;
   int done;
   uint8 c;

   blank = FALSE;
   altchars = FALSE;
   printer = FALSE;
   simhfmt = FALSE;
   termc = 072;
   chkc = 0132;

   for (optind = 1, optarg = argv[optind];
       (optind < argc) && (*optarg == '-');
       optind++, optarg = argv[optind])
   {
      ++optarg;
      while (*optarg)
      {
         switch (*optarg++)
	 {

         case 's':
	    simhfmt = TRUE;
            /* Fall through */

         case 'a':
            altchars = TRUE;
	    termc = 0132;
	    chkc = 072;
            break;

         case 'b':
	    blank = TRUE;
            break;

         case 'p':
	    printer = TRUE;
            break;

         default:
            fprintf (stderr,
	       "Usage: bcd2txt [-option] infile [outfile] [reclen [blklen]]\n");
            fprintf (stderr, "  -a     Use Alternate character set\n");
            fprintf (stderr, "  -p     Convert printer controls\n");
            fprintf (stderr, "  -s     Use simh format\n");
            exit (1);
         }
      }
   }

   blklen = 84;
   reclen = 80;

   parsefiles (argc - (optind-1), &argv[optind-1], "bcd", "txt",
	       &reclen, (int *)&blklen);

   if ((fi = fopen (fin, "rb")) == NULL)
   {
      perror (fin);
      exit (1);
   }
   if ((fo = fopen (fon, "w")) == NULL)
   {
      perror (fon);
      exit (1);
   }

   p = record;
   fileflag = TRUE;
   done = FALSE;
   while (!done)
   {
      if (readblock (fi) < 0)
      {
         done = TRUE;
      }

      else
      {
	 int skiprem;

	 skiprem = FALSE;
	 while (chrblk < blklen)
	 {
	    c = block[chrblk++];
	    chrrec++;

	    if (c & 0200 || (!printer && (p - record == reclen)) || c == termc)
	    {
	       if (!printer && ((blklen - (chrblk-1)) < (unsigned)reclen))
	       {
		  chrblk = blklen;
		  skiprem = TRUE;
	       }

	       p = outputrec (fo, p, c);
	       if (printer) c = termc;
	    }

	    if (!skiprem && c != termc)
	    {
	       if (c == 0217)
	       {
		  fputc ('\n', fo);
		  fileflag = TRUE;
	       }
	       else if (c != chkc)
	       {
		  if (blank && (c & 077) == 020)
		     *p++ = ' ';
		  else 
		     *p++ = unmapchar (c);
	       }
	    }
	 }
      }
   }

   p = outputrec (fo, p, 0377);

   fclose (fi);
   fclose (fo);

   return (0);
}
